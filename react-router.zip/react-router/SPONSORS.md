The following companies have provided sponsorship toward the development
of React Router. Thank you!

- [React Training](https://reactjs-training.com)
- [![Modus Create](http://i.imgur.com/FxzUtvl.png)](http://moduscreate.com/)
- [![Instructure](http://i.imgur.com/kMZauLm.png)](https://www.instructure.com/)

